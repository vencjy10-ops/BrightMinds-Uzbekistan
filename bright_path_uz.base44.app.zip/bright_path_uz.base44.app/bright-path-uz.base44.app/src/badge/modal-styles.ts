// DS PromoModal ("with-image", size "minimum") rebuilt in plain CSS: this bundle runs inside
// third-party apps, so it can't mount React or the DesignSystemProvider. UI values are the resolved
// tokens from packages/design-system/src/tokens/tokens-vars.css — keep them in sync. The cover's
// title and placeholder colours come from the illustration's Figma frame, not from tokens.
export const MODAL_CSS = `
  :host { all: initial; }
  *, *::before, *::after { box-sizing: border-box; }
  .overlay {
    --surface: #ffffff;
    --text: #0f0e0e;
    --text-secondary: #5d5d5d;
    --primary: #0f0e0e;
    --primary-hover: #3a3939;
    --primary-active: #5d5d5d;
    --primary-text: #fcfcfc;
    --secondary-hover: #e9e6e0;
    --secondary-active: #ddd8d2;
    --border-strong: #c9c3bc;
    --border-strong-focus: #99928b;
    --border: #ddd8d2;
    --footnote: #f5f5f4;
    --focus-ring: #3b51e5;
    --scrim: #0f0e0e4d;
    --shadow: 0 20px 30px 0 rgba(15, 14, 14, 0.1), 0 0 4px 0 rgba(15, 14, 14, 0.1);
    --font-brand: "Base44 Badge Brand", system-ui, sans-serif;
    --font-body: "Base44 Badge Text", system-ui, sans-serif;
    --font-titles: "Base44 Badge Titles", system-ui, sans-serif;

    position: fixed;
    inset: 0;
    z-index: 1000000;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 48px;
    background: var(--scrim);
    backdrop-filter: blur(4px);
    font-family: var(--font-body);
    color-scheme: light;
    animation: fade-in 0.2s ease-out;
  }

  @media (prefers-color-scheme: dark) {
    .overlay {
      --surface: #161616;
      --text: #ebebeb;
      --text-secondary: #c0c0c0;
      --primary: #ebebeb;
      --primary-hover: #c0c0c0;
      --primary-active: #929292;
      --primary-text: #252424;
      --secondary-hover: #5d5a57;
      --secondary-active: #3d3c3a;
      --border-strong: #5d5a57;
      --border: #3d3c3a;
      --footnote: #1b1c1e;
      --focus-ring: #7e90f5;
      --scrim: #ffffff1a;
      --shadow: none;
      color-scheme: dark;
    }
  }

  .panel {
    position: relative;
    display: flex;
    flex-direction: column;
    width: 512px;
    max-width: 100%;
    max-height: min(85dvh, calc(100dvh - 96px));
    overflow-y: auto; /* the whole card scrolls, so the actions stay reachable on short viewports */
    border-radius: 8px;
    background: var(--surface);
    color: var(--text);
    box-shadow: var(--shadow);
    outline: none;
    animation: scale-in 0.2s ease-out;
  }

  /* The cover is a fixed grey illustration in both themes, so the title and close on it stay dark. */
  .image { position: relative; flex-shrink: 0; width: 100%; aspect-ratio: 512 / 280; overflow: clip; background: #c4c4c4; }
  .image img { display: block; width: 100%; height: 100%; object-fit: cover; }
  .title {
    position: absolute;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0;
    color: #0f1e24;
    font-family: var(--font-brand);
    font-weight: 560;
    font-size: 34px;
    line-height: 43px;
    letter-spacing: -0.5px;
    text-align: center;
  }

  .content { display: flex; flex-direction: column; gap: 24px; padding: 28px 40px; }
  .message { display: flex; flex-direction: column; gap: 6px; text-align: center; }
  .heading { margin: 0; font: 600 20px/24px var(--font-titles); letter-spacing: -0.1px; }
  .description { margin: 0; font-size: 14px; line-height: 18px; }

  .actions { display: flex; flex-shrink: 0; justify-content: center; gap: 12px; }
  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
    height: 36px;
    padding: 0 16px;
    border: 1px solid transparent;
    border-radius: 6px;
    font: 460 14px/18px var(--font-body);
    white-space: nowrap;
    cursor: pointer;
    transition: background-color 120ms, border-color 120ms;
  }
  .btn:focus-visible { outline: none; box-shadow: 0 0 0 3px var(--focus-ring); }
  .btn[aria-busy="true"] { pointer-events: none; }
  .btn-primary { border: none; background: var(--primary); color: var(--primary-text); }
  .btn-primary:active { background: var(--primary-active); }
  .btn-secondary { border-color: var(--border-strong); background: transparent; color: var(--text); }
  .btn-secondary:focus-visible { border-color: var(--border-strong-focus); }
  .btn-secondary:active { border-color: var(--border-strong-focus); background: var(--secondary-active); }
  @media (hover: hover) {
    .btn-primary:hover { background: var(--primary-hover); }
    .btn-secondary:hover { border-color: var(--border-strong-focus); background: var(--secondary-hover); }
    .close:hover { background: #0f0e0e1a; }
  }

  /* Sticky (not absolute) so it stays in view while the card scrolls; order + negative margin lay it over the image. */
  .close {
    position: sticky;
    top: 12px;
    z-index: 10;
    order: -1;
    align-self: flex-end;
    flex-shrink: 0;
    margin: 12px 12px -36px 0;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 24px;
    height: 24px;
    padding: 0;
    border: none;
    border-radius: 9999px;
    background: transparent;
    color: #0f0e0e;
    cursor: pointer;
    transition: background-color 120ms;
  }
  .close:active { background: #0f0e0e1a; }
  .close:focus-visible { outline: none; box-shadow: 0 0 0 3px var(--focus-ring); }
  /* A sticky close can scroll over the dark card, where the dark glyph would vanish. */
  @media (prefers-color-scheme: dark) {
    .close { background: #ffffffcc; }
    .close:hover, .close:active { background: #ffffff; }
  }

  .footnote {
    flex-shrink: 0;
    padding: 12px 40px;
    border-top: 1px solid var(--border);
    background: var(--footnote);
    color: var(--text-secondary);
    font-size: 14px;
    line-height: 18px;
    text-align: center;
  }
  .footnote a { color: var(--text); text-decoration: underline; }
  .footnote a:focus-visible { outline: 2px solid var(--focus-ring); outline-offset: 2px; border-radius: 2px; }

  .spinner { animation: spin 1s linear infinite; }
  @media (max-width: 639px) {
    .overlay { align-items: flex-end; padding: 0; }
    .panel { width: 100%; max-height: 90dvh; border-radius: 12px 12px 0 0; animation-name: slide-up-in; }
    .content { padding: 24px 20px 40px; }
    .title { font-size: 28px; line-height: 32px; }
    .actions { flex-direction: column-reverse; gap: 8px; }
    .footnote { padding: 12px 20px; }
  }

  @media (prefers-reduced-motion: reduce) {
    .overlay, .panel, .spinner { animation: none; }
  }

  @keyframes fade-in { from { opacity: 0; } to { opacity: 1; } }
  @keyframes scale-in { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
  @keyframes slide-up-in { from { transform: translateY(100%); } to { transform: translateY(0); } }
  @keyframes spin { to { transform: rotate(360deg); } }
`;
