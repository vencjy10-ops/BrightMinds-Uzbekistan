/**
 * Fires a badge analytics event to the backend (fire-and-forget)
 */
export function trackBadgeEvent(
  platformUrl: string,
  appId: string,
  event: string,
  properties?: Record<string, unknown>,
): void {
  fetch(`${platformUrl}/api/apps/public/badge/${appId}/events`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(properties ? { event, properties } : { event }),
  }).catch(() => {
    // Silently fail - analytics must never break the badge
  });
}
