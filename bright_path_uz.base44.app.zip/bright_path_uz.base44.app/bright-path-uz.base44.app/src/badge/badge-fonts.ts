import dazzedSemibold from '../../../../packages/design-system/src/tokens/fonts/dazzed-semibold.woff2';
import madeforDisplay from '../../../../packages/design-system/src/tokens/fonts/wix-madefor-display-latin.woff2';
import madeforText from '../../../../packages/design-system/src/tokens/fonts/wix-madefor-text-latin.woff2';

const FONT_STYLE_ID = 'base44-badge-fonts';

// @font-face is ignored inside a shadow root, so the faces go on the document under
// badge-only family names. Files are fetched on first use, i.e. when the modal opens.
export function ensureBadgeFonts(assetBaseUrl: string): void {
  if (document.getElementById(FONT_STYLE_ID)) return;
  const style = document.createElement('style');
  style.id = FONT_STYLE_ID;
  style.textContent = `
    @font-face { font-family: "Base44 Badge Brand"; font-weight: 500 700; font-display: swap;
      src: url("${new URL(dazzedSemibold, assetBaseUrl)}") format("woff2"); }
    @font-face { font-family: "Base44 Badge Text"; font-weight: 400 800; font-display: swap;
      src: url("${new URL(madeforText, assetBaseUrl)}") format("woff2"); }
    @font-face { font-family: "Base44 Badge Titles"; font-weight: 400 800; font-display: swap;
      src: url("${new URL(madeforDisplay, assetBaseUrl)}") format("woff2"); }
  `;
  document.head.appendChild(style);
}
