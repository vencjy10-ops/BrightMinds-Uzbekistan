import { ensureBadgeFonts } from './badge-fonts';
import { MODAL_CSS } from './modal-styles';
import { trackBadgeEvent } from './track';

// DS DismissSmall glyph (@wix/wix-ui-icons-common/odeditor), as used by the DS CloseButton.
const DismissIcon = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="currentColor" aria-hidden="true"><path d="M11.72 5.22a.75.75 0 1 1 1.06 1.06L10.06 9l2.72 2.72a.75.75 0 0 1-1.06 1.06L9 10.06l-2.72 2.72a.75.75 0 0 1-1.06-1.06L7.94 9 5.22 6.28a.75.75 0 1 1 1.06-1.06L9 7.94l2.72-2.72Z"/></svg>';

const SpinnerIcon = '<svg class="spinner" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><path d="M21 12a9 9 0 1 1-6.22-8.56"/></svg>';

const COVER_URL = 'https://media.base44.com/images/public/builder-assets/badge-cover.webp';

const FOCUSABLE = 'button:not([disabled]), a[href]';

function escapeHtml(text: string): string {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function modalMarkup(allowClone: boolean, coverUrl: string): string {
  return `
    <div class="overlay">
      <div class="panel" data-testid="badge-modal" role="dialog" aria-modal="true" aria-labelledby="base44-modal-title"
        aria-describedby="base44-modal-description" tabindex="-1">
        <div class="image">
          <img src="${coverUrl}" alt="" />
          <h2 class="title" id="base44-modal-title">Built with Base44</h2>
        </div>
        <div class="content">
          <div class="message" id="base44-modal-description">
            <p class="heading">Turn ideas into working apps with Base44</p>
            <p class="description">Ready to build your own app?</p>
          </div>
          <div class="actions">
            ${allowClone ? '<button type="button" class="btn btn-secondary" id="modal-clone-app" data-testid="badge-modal-clone-app">Clone this app</button>' : ''}
            <button type="button" class="btn btn-primary" id="modal-go-to-base44" data-testid="badge-modal-go-to-base44">Go to Base44</button>
          </div>
        </div>
        <div class="footnote" id="admin-footer" data-testid="badge-modal-admin-footnote" hidden></div>
        <button type="button" class="close" id="modal-close-btn" data-testid="badge-modal-close" aria-label="Close">${DismissIcon}</button>
      </div>
    </div>
  `;
}

export function createModal(appId: string, platformUrl: string, allowClone: boolean, assetBaseUrl: string): HTMLElement {
  ensureBadgeFonts(assetBaseUrl);

  const host = document.createElement('div');
  host.id = 'base44-modal-overlay';
  host.dir = 'ltr';
  // Inline so host-page CSS can't restyle the host and trap the overlay in its stacking context.
  host.style.cssText = 'position:fixed;inset:0;z-index:1000000;display:block';
  const root = host.attachShadow({ mode: 'open' });
  root.innerHTML = `<style>${MODAL_CSS}</style>${modalMarkup(allowClone, COVER_URL)}`;

  const overlay = root.querySelector('.overlay') as HTMLDivElement;
  const panel = root.querySelector('.panel') as HTMLDivElement;
  const previousFocus = document.activeElement as HTMLElement | null;
  let buttonActionTaken = false;

  function close() {
    document.removeEventListener('keydown', onKeyDown, true);
    host.remove();
    previousFocus?.focus?.();
  }

  function dismiss() {
    if (buttonActionTaken) return;
    trackBadgeEvent(platformUrl, appId, 'modal_closed');
    close();
  }

  function onKeyDown(e: KeyboardEvent) {
    if (!host.isConnected) {
      document.removeEventListener('keydown', onKeyDown, true);
      return;
    }
    if (e.key === 'Escape') {
      e.stopPropagation();
      dismiss();
      return;
    }
    if (e.key !== 'Tab') return;
    const focusable = Array.from(root.querySelectorAll<HTMLElement>(FOCUSABLE)).filter((el) => !el.hidden && el.offsetParent !== null);
    if (focusable.length === 0) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    const active = root.activeElement;
    if (e.shiftKey && (active === first || active === panel)) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && active === last) {
      e.preventDefault();
      first.focus();
    }
  }

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) dismiss();
  });
  root.getElementById('modal-close-btn')!.addEventListener('click', dismiss);

  root.getElementById('modal-go-to-base44')!.addEventListener('click', () => {
    if (buttonActionTaken) return;
    buttonActionTaken = true;
    trackBadgeEvent(platformUrl, appId, 'modal_go_to_base44');
    window.open(platformUrl, '_blank');
    close();
  });

  const cloneBtn = root.getElementById('modal-clone-app');
  cloneBtn?.addEventListener('click', () => {
    if (buttonActionTaken) return;
    buttonActionTaken = true;
    trackBadgeEvent(platformUrl, appId, 'modal_clone_app');
    cloneBtn.setAttribute('aria-busy', 'true');
    cloneBtn.innerHTML = `${SpinnerIcon}<span>Cloning</span>`;
    window.open(platformUrl + '/remix-app/' + appId, '_blank');
    setTimeout(close, 1000);
  });

  document.addEventListener('keydown', onKeyDown, true);
  requestAnimationFrame(() => panel.focus());
  showAdminFooter(appId, platformUrl, root);

  return host;
}

function showAdminFooter(appId: string, platformUrl: string, root: ShadowRoot) {
  const token = localStorage.getItem('token');
  if (!token) return;

  fetch(`${platformUrl}/api/apps/${appId}/entities/User/me`, {
    headers: { Authorization: `Bearer ${token}` },
  })
    .then((response) => (response.ok ? response.json() : null))
    .then((data) => {
      if (data?.role !== 'admin') return;
      const footer = root.getElementById('admin-footer');
      if (!footer) return;
      const settingsUrl = `${escapeHtml(platformUrl)}/apps/${escapeHtml(appId)}/editor/workspace/app-settings`;
      footer.innerHTML = `This badge is part of the app experience. Hiding the badge is available on paid plans in the <a href="${settingsUrl}" target="_blank" rel="noopener noreferrer" data-testid="badge-modal-settings-link">app settings</a>.`;
      footer.hidden = false;
    })
    .catch(() => {
      // Silently fail if the request fails
    });
}
