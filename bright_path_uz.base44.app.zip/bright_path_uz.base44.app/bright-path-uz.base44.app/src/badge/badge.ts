/**
 * Standalone Badge Script for Base44
 * Renders the "Edit with Base44" badge on remixable apps
 * No dependencies - pure vanilla JavaScript
 */

// Import badge assets
import base44Text from './assets/base44_text.png';
import { createModal } from './modal';
import { trackBadgeEvent } from './track';

// New-brand sun symbol — referenced from the Wix Media CDN (single source of truth,
// so a brand update needs no badge rebuild). Same URL as NEW_BRAND_SYMBOL_PNG_SRC in
// src/constants/brandAssets.ts; duplicated as a literal because this standalone
// esbuild bundle can't resolve the app's `@/` alias — keep the two in sync.
const NEW_BRAND_SYMBOL_PNG_SRC = 'https://media.base44.com/images/public/builder-assets/symbol-orange.png';

(function() {
  'use strict';

  // SVG Icons as strings
  const XIcon = '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>';


  /**
   * Sanitizes a platform URL to prevent XSS attacks
   * Only allows http:// and https:// protocols
   */
  function sanitizePlatformUrl(url: string): string | null {
    if (!url) return null;

    try {
      const parsed = new URL(url);

      // Only allow http and https protocols
      if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
        console.warn('Base44 badge: Invalid protocol in platform URL. Only http and https are allowed.');
        return null;
      }

      // Return the sanitized URL
      return parsed.origin;
    } catch (e) {
      console.warn('Base44 badge: Invalid platform URL provided');
      return null;
    }
  }

  /**
   * Sanitizes an app ID to prevent injection attacks
   * Only allows alphanumeric characters (letters and numbers)
   */
  function sanitizeAppId(appId: string): string | null {
    if (!appId) return null;

    // Only allow alphanumeric characters (letters and numbers only)
    const sanitized = appId.replace(/[^a-zA-Z0-9]/g, '');

    if (sanitized !== appId) {
      console.warn('Base44 badge: App ID contained invalid characters and was sanitized');
    }

    return sanitized || null;
  }

  function createBadgeElement(appId, platformUrl, allowClone, assetBaseUrl) {
    const badge = document.createElement('div');
    badge.id = 'base44-edit-badge';
    badge.dir = 'ltr';

    // Apply styles
    Object.assign(badge.style, {
      position: 'fixed',
      zIndex: '999999',
      bottom: '16px',
      right: '16px',
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      backgroundColor: '#000000',
      color: '#ffffff',
      padding: '8px 12px',
      borderRadius: '6px',
      boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
      cursor: 'pointer',
      transition: 'box-shadow 0.2s',
      border: '1px solid #262626',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
      fontSize: '14px',
    });

    badge.innerHTML = `
      <img
        src="${NEW_BRAND_SYMBOL_PNG_SRC}"
        alt="base44"
        style="width: 20px; height: 20px;"
      />
      <span style="white-space: nowrap; font-size: 12px;">
        <span id="badge-content">
          <div style="display: flex; align-items: center; gap: 6px; justify-content: center; font-size: 14px;">
            <span>${allowClone ? 'Edit with ' : 'Made with '}</span>
            <span style="margin-bottom: 2px;"><img src="${base44Text}" alt="Base44" height="18" width="56" /></span>
          </div>
        </span>
      </span>
      <button
        id="badge-close"
        aria-label="Close badge"
        style="
          padding: 2px;
          margin-left: 2px;
          border-radius: 9999px;
          background: transparent;
          border: none;
          cursor: pointer;
          transition: background-color 0.2s;
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
        "
      >
        ${XIcon}
      </button>
    `;

    // Add hover effect
    badge.addEventListener('mouseenter', function() {
      badge.style.boxShadow = '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)';
    });
    badge.addEventListener('mouseleave', function() {
      badge.style.boxShadow = '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)';
    });

    // Handle close button
    const closeButton = badge.querySelector('#badge-close') as HTMLButtonElement;
    closeButton.addEventListener('mouseenter', function(e) {
      (e.target as HTMLButtonElement).style.backgroundColor = '#404040';
    });
    closeButton.addEventListener('mouseleave', function(e) {
      (e.target as HTMLButtonElement).style.backgroundColor = 'transparent';
    });
    closeButton.addEventListener('click', function(e) {
      e.stopPropagation();
      trackBadgeEvent(platformUrl, appId, 'badge_dismissed');
      badge.remove();
    });

    // Handle badge click
    badge.addEventListener('click', function() {
      trackBadgeEvent(platformUrl, appId, 'badge_clicked');
      const modal = createModal(appId, platformUrl, allowClone, assetBaseUrl);
      document.body.appendChild(modal);
    });

    return badge;
  }

  // Capture script tag reference at top level (before any callbacks)
  const scriptTag = document.currentScript;

  function renderBadge() {
    // Use the captured script tag reference
    if (!scriptTag) {
      console.warn('Base44 badge: Could not find script tag with data-app-id');
      return;
    }

    const rawAppId = scriptTag.getAttribute('data-app-id');
    const rawPlatformUrl = scriptTag.getAttribute('data-platform-url') || 'https://app.base44.com';
    const allowClone = scriptTag.getAttribute('data-allow-clone') !== 'false';

    // Sanitize inputs
    const appId = sanitizeAppId(rawAppId || '');
    const platformUrl = sanitizePlatformUrl(rawPlatformUrl);

    if (!appId) {
      console.warn('Base44 badge: data-app-id attribute is required and must be valid');
      return;
    }

    if (!platformUrl) {
      console.warn('Base44 badge: data-platform-url must be a valid http or https URL');
      return;
    }

    // Create and append badge
    const badge = createBadgeElement(appId, platformUrl, allowClone, new URL('/static/js/', (scriptTag as HTMLScriptElement).src || document.baseURI).href);
    document.body.appendChild(badge);
  }

  // Initialize badge when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', renderBadge);
  } else {
    // DOM already loaded
    renderBadge();
  }
})();
